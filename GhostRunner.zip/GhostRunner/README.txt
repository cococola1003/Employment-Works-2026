・開発期間：2月間

・経緯：現代ゲームプログラムやゲームエンジン構造（フレームワーク）の研究のため、C++のみで作りました。

・利用したライブ：SDL3、GLM

・人数：一人

・担当箇所：ゲームプレイ設計、プログラマー

・ファイル構造：
	GhostRunnerフォルダ
		|
		|_  README.txt　：説明ドキュメント
		|
		|_  GhostRunner-Windows.exe　：実行ファイル
		|
		|_  assetsフォルダ　：ゲームアセット
		|
		|_  srcフォルダ　：ソースコード
		|
		|_  CMakeLists.txt　：ソースコード編集セット
		|
		|_  SDL3_mixer.dll　：実行ファイル稼働必須な.dll
		     SDL3.dll
		     SDL3_image.dll
		     SDL3_ttf.dll

・GhostRunner-Windows.exeがassestsフォルダーと.dll依存しますので、展開した後そのまま起動してください。

・ゲーム操作：
	プレイヤー移動：キーボード　W(上)　S(下)　A(左)　D(右)
	プレイヤー狙う：マウス　移動
	プレイヤー攻撃：マウス　左ボタン
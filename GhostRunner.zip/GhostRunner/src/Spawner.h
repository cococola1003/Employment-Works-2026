/* Spawner Class -> Object Class
   生成器
   継続的な挑戦：敵を次々と出現させることで、プレイヤーに絶え間ない試練を与える
   動的難易度調整：ゲームの進行状況やプレイヤーの技量に応じて、敵の出現速度と数を調整できます
   リソース管理：シーン内の敵の数を制御し、リソースの過剰消費を防ぐ
   ゲームのテンポ調整：生成間隔と出現数を調節し、緊張感と安らぎのバランスを制御する
   ランダム性：ゲームの予測不能性を高め、遊びごたえと再プレイ価値を向上させる
 */
#ifndef SPAWNER_H
#define SPAWNER_H

#include "core/Object.h"
class Player;
class Spawner : public Object
{
protected:
    int num_ = 20;             // 生成数
    float timer_ = 0;          // 生成タイマー
    float interval_ = 3.0f;    // 生成間隔（秒）
    Player *target_ = nullptr; // 目標プレイヤー

public:
    virtual void update(float dt) override;

    int getNum() const { return num_; }
    void setNum(int num) { num_ = num; }
    float getTimer() const { return timer_; }
    void setTimer(float timer) { timer_ = timer; }
    float getInterval() const { return interval_; }
    void setInterval(float interval) { interval_ = interval; }
    Player *getTarget() const { return target_; }
    void setTarget(Player *target) { target_ = target; }
};

#endif // SPAWNER_H
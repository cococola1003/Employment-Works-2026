/* ObjectScreen Class -> Object Class
   主な機能は、オブジェクトの画面表示位置を制御することです
   UI 要素や画面座標系で直接位置指定するオブジェクトに非常に便利です
*/
#ifndef OBJECT_SCREEN_H
#define OBJECT_SCREEN_H

#include "Object.h"

class ObjectScreen : public Object
{
protected:
    glm::vec2 render_position_ = glm::vec2(0, 0); // 画面上の描画位置

public:
    virtual void init() override { type_ = ObjectType::OBJECT_SCREEN; }
    glm::vec2 getRenderPosition() const { return render_position_; }
    virtual void setRenderPosition(const glm::vec2 &render_position) { render_position_ = render_position; }
    virtual glm::vec2 getPosition() const { return glm::vec2(0); }
};

#endif // OBJECT_SCREEN_H
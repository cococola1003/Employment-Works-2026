/* AssetStore Class
   ゲーム内の全リソースを管理し、種類別に無順序マップで格納するとともに、リソースの読み込みと取得機能を提供する
   重複読み込み防止 - 同一リソースが複数箇所で使用される場合があるため、各リソースが必ず1 回のみ読み込まれるようにする必要があります
   統一インターフェース: 様々な種類のリソースを読み込み・アクセスするための共通インターフェースを提供
   リソース解放: 適切なタイミング（ゲーム終了時など）で全てのリソースを解放し、メモリリークを防ぐ
   エラー処理: 読み込み失敗時の対応
   遅延ロード: 必要な時のみリソースを読み込み、全リソースの一括読み込みによる起動時間の遅延を防止
*/
#ifndef ASSET_STORE_H
#define ASSET_STORE_H
#include <unordered_map>
#include <SDL3/SDL.h>
#include <SDL3_image/SDL_image.h>
#include <SDL3_mixer/SDL_mixer.h>
#include <SDL3_ttf/SDL_ttf.h>
#include <string>

class AssetStore
{
    SDL_Renderer *renderer_ = nullptr;                        // 画像リソースの読み込みに使用
    std::unordered_map<std::string, SDL_Texture *> textures_; // 画像リソースを保存
    std::unordered_map<std::string, Mix_Chunk *> sounds_;     // サウンドエフェクトリソースの保存
    std::unordered_map<std::string, Mix_Music *> music_;      // BGMの保存
    std::unordered_map<std::string, TTF_Font *> fonts_;       // フォントリソースの保存

public:
    AssetStore(SDL_Renderer *renderer) { renderer_ = renderer; }
    ~AssetStore() = default;

    void clean();

    void loadImage(const std::string &file_path);
    SDL_Texture *getImage(const std::string &file_path);

    void loadSound(const std::string &file_path);
    Mix_Chunk *getSound(const std::string &file_path);

    void loadMusic(const std::string &file_path);
    Mix_Music *getMusic(const std::string &file_path);

    void loadFont(const std::string &file_path, int font_size);
    TTF_Font *getFont(const std::string &file_path, int font_size);
};

#endif // ASSET_STORE_H
/* Scene Class -> Object Class
   管理画面でのオブジェクト操作機能を拡張しました
   カメラの位置情報を保持し、ビューポートの移動やワールド座標との変換に利用されます
   std::vector<Object*>でシーン内の全ゲームオブジェクトを管理する
   Objectの全ての基本メソッドを継承しており、シーン自体もゲームオブジェクトとなります
   各シーンは独立したモジュール構成になっており、分業開発やコード管理がしやすくなっています
   新規シーンを追加するには、Sceneのサブクラスを作成し、必要なメソッドを実装するだけで完了します
   シーンは含まれる全てのオブジェクトを管理可能で、リソースの割り当てと解放を効率化します
*/
#ifndef SCENE_H
#define SCENE_H

#include "Object.h"
#include "ObjectWorld.h"
#include <glm/glm.hpp>
#include <vector>
#include <string>

class Scene : public Object
{
protected:
    glm::vec2 camera_position_ = glm::vec2(0); // カメラ位置
    glm::vec2 world_size_ = glm::vec2(0);      // シーンサイズ

    std::vector<ObjectWorld *> children_world_;   // 世界オブジェクト
    std::vector<ObjectScreen *> children_screen_; // スクリーンオブジェクト
    bool is_pause_ = false;                       // ゲームのポーズ状態

public:
    Scene() = default;
    virtual ~Scene() = default;

    virtual void init() override {}
    virtual bool handleEvents(SDL_Event &event) override;
    virtual void update(float dt) override;
    virtual void render() override;
    virtual void clean() override;

    virtual void addChild(Object *child) override;
    virtual void removeChild(Object *child) override;

    virtual void saveData(const std::string &) {} // 保存データ
    virtual void loadData(const std::string &) {} // 読み込みデータ

    glm::vec2 worldToScreen(const glm::vec2 &world_position) const { return world_position - camera_position_; }   // 世界座標をスクリーン座標に変換
    glm::vec2 screenToWorld(const glm::vec2 &screen_position) const { return screen_position + camera_position_; } // スクリーン座標を世界座標に変換

    void pause();  // ゲームを一時停止
    void resume(); // ゲームを再開

    glm::vec2 getCameraPosition() const { return camera_position_; }
    void setCameraPosition(const glm::vec2 &camera_position);
    glm::vec2 getWorldSize() const { return world_size_; }
    void setWorldSize(const glm::vec2 &world_size) { world_size_ = world_size; }
    std::vector<ObjectScreen *> &getChildrenScreen() { return children_screen_; }
    std::vector<ObjectWorld *> &getChildrenWorld() { return children_world_; }
};

#endif // SCENE_H
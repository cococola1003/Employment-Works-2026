/* Define
   ObjectType Enum
   異なる種類のオブジェクトを分類する
   オブジェクトの種類に応じて異なる処理を行う
 */
#ifndef DEFS_H
#define DEFS_H

// #define DEBUG_MODE

enum class ObjectType
{
  NONE,
  OBJECT_SCREEN, // 画面オブジェクト、画面座標系における位置指定
  OBJECT_WORLD,  // ワールドオブジェクト、ワールド座標系での位置指定
  ENEMY,         // 敵オブジェクト
};

enum class Anchor // オブジェクトアンカー
{
  NONE,
  TOP_LEFT,
  TOP_CENTER,
  TOP_RIGHT,
  CENTER_LEFT,
  CENTER,
  CENTER_RIGHT,
  BOTTOM_LEFT,
  BOTTOM_CENTER,
  BOTTOM_RIGHT,
};

#endif // DEFS_H
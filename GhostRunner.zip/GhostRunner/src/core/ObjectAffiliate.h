/* ObjectAffiliate Class -> Object Class
   対象システム
   オブジェクト（主体）が複数の関連オブジェクト（添付物）を保持できるようにする
   通常の親子関係とは異なり、付属オブジェクトの位置と動作は親オブジェクトに直接依存しています
   ゲーム内のビジュアル要素（スプライトやパーティクル効果など）の表示に最適です
*/
#ifndef OBJECT_AFFILIATE_H
#define OBJECT_AFFILIATE_H

#include "ObjectScreen.h"

class ObjectAffiliate : public Object
{
protected:
    ObjectScreen *parent_ = nullptr;     // 親ノード
    glm::vec2 offset_ = glm::vec2(0, 0); // 相対的なオフセット
    glm::vec2 size_ = glm::vec2(0, 0);
    Anchor anchor_ = Anchor::CENTER; // アンカー

public:
    ObjectScreen *getParent() const { return parent_; }
    void setParent(ObjectScreen *parent) { parent_ = parent; }
    glm::vec2 getOffset() const { return offset_; }
    void setOffset(const glm::vec2 &offset) { offset_ = offset; }
    glm::vec2 getSize() const { return size_; }
    void setSize(const glm::vec2 &size);
    void setScale(float scale);
    Anchor getAnchor() const { return anchor_; }
    void setAnchor(Anchor anchor) { anchor_ = anchor; }
    void setOffsetByAnchor(Anchor anchor);
};

#endif // OBJECT_AFFILIATE_H
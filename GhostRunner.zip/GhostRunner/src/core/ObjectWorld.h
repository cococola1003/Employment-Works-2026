/* ObjectWorld Class -> ObjectScreen Class -> Object Class
   ObjectScreenを継承し、ワールド座標系における位置情報を追加したもの
*/
#ifndef OBJECT_WORLD_H
#define OBJECT_WORLD_H

#include "ObjectScreen.h"
#include "../affiliate/Collider.h"

class ObjectWorld : public ObjectScreen
{
protected:
    glm::vec2 position_ = glm::vec2(0, 0); // ワールド座標系
    Collider *collider_ = nullptr;

public:
    virtual void init() override { type_ = ObjectType::OBJECT_WORLD; }
    virtual void update(float dt) override;

    glm::vec2 getPosition() const { return position_; }
    void setPosition(const glm::vec2 &position);
    virtual void setRenderPosition(const glm::vec2 &render_position) override;
    Collider *getCollider() { return collider_; }
    void setCollider(Collider *collider) { collider_ = collider; }
    virtual void takeDamage(float) { return; }
};

#endif // OBJECT_WORLD_H
/* Actor Class -> ObjectWorld Class -> ObjectScreen Class -> Object Class
   移動可能なキャラクターに対応
*/
#ifndef ACTOR_H
#define ACTOR_H

#include "ObjectWorld.h"

class Stats;
class AffiliateBar;
class Actor : public ObjectWorld
{
protected:
    glm::vec2 velocity_ = glm::vec2(0, 0); // 速度
    float max_speed_ = 100.0f;             // 最大速度
    Stats *stats_ = nullptr;               // キャラクター属性
    AffiliateBar *health_bar_ = nullptr;   // HP

public:
    virtual void update(float dt) override;

    void move(float dt);

    glm::vec2 getVelocity() const { return velocity_; }
    void setVelocity(const glm::vec2 &velocity) { velocity_ = velocity; }
    float getMaxSpeed() const { return max_speed_; }
    void setMaxSpeed(float max_speed) { max_speed_ = max_speed; }

    Stats *getStats() const { return stats_; }
    void setStats(Stats *stats) { stats_ = stats; }
    void setHealthBar(AffiliateBar *health_bar) { health_bar_ = health_bar; }
    AffiliateBar *getHealthBar() const { return health_bar_; }
    virtual void takeDamage(float damage) override;
    bool getIsAlive() const;

private:
    void updateHealthBar();
};

#endif // ACTOR_H
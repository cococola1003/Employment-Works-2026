/* Object Class
   操作可能なすべてのゲーム要素はObjectクラスを継承しており、ゲームオブジェクトの基本動作を定義しています
   Gameシングルトンの参照を保持することで、ゲームリソースへのアクセスを簡便化する
   初期化、更新、描画、クリーンアップなどのメソッドを定義しています
   SDLイベント処理用のインターフェースを提供しています
   すべてのメソッドは仮想関数として実装されており、サブクラスでこれらの動作を自由にオーバーライドできます
   継承チェーンが存在する場合、各サブクラスはシステム全体の整合性を保つため、必ず親クラスのライフサイクルメソッドを呼び出すようにしてください

   問題：コンテナをイテレート中に変更すると未定義動作を引き起こす可能性があります 例：updateメソッド内でchildren_コンテナを走査しながら子オブジェクトの追加・削除を行う場合
   解決策：追加と削除の手順を分け、まず新しいコンテナで追加処理を行った後、通常のコンテナを処理します。
*/
#ifndef OBJECT_H
#define OBJECT_H

#include "Game.h"
#include "Defs.h"
#include <vector>

class Object
{
protected:
    ObjectType type_ = ObjectType::NONE; // ゲームオブジェクトの種類
    Game &game_ = Game::GetInstance();

    std::vector<Object *> object_to_add_; // 追加対象のリスト
    std::vector<Object *> children_;      // 子オブジェクト一覧

    bool is_active_ = true;    // ゲームオブジェクトが有効化されているか
    bool need_remove_ = false; // ゲームオブジェクトを削除する必要がありますか

public:
    Object() = default;
    virtual ~Object() = default; // すべてのクラスにおいて、コンストラクタとデストラクタ内では処理を実行しない

    virtual void init() {}
    virtual bool handleEvents(SDL_Event &event);
    virtual void update(float dt);
    virtual void render();
    virtual void clean();

    void safeAddChild(Object *child) { object_to_add_.push_back(child); }
    virtual void addChild(Object *child) { children_.push_back(child); }
    virtual void removeChild(Object *child)
    {
        children_.erase(std::remove(children_.begin(), children_.end(), child), children_.end());
    }

    ObjectType getType() const { return type_; }
    void setType(ObjectType type) { type_ = type; }
    void setActive(bool active) { is_active_ = active; }
    bool getActive() const { return is_active_; }
    bool getNeedRemove() const { return need_remove_; }
    void setNeedRemove(bool need_remove) { need_remove_ = need_remove; }
};

#endif // OBJECT_H
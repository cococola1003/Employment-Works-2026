/* HUDSkill Class -> ObjectScreen Class -> Object Class
   スキルクールダウン表示
   視認性を確保：スキルアイコンは十分な大きさとし、クールダウン状態が瞬時に把握できるようにする
   リアルタイム更新：スキルのクールダウン状況をリアルタイムで表示可能
   配置が適切：通常は画面端に配置され、ゲームのメイン表示を妨げない
   視覚的フィードバック：スキルの使用可否が一目でわかるように明確な視覚的表示を行う
   拡張性：システムは複数のスキルのクールダウン表示に対応できるよう、容易に拡張可能であること
*/
#ifndef HUD_SKILL_H
#define HUD_SKILL_H

#include "../core/ObjectScreen.h"

class Sprite;
class HUDSkill : public ObjectScreen
{
protected:
    Sprite *icon_ = nullptr;
    float percentage_ = 1.0f;

public:
    static HUDSkill *addHUDSkillChild(Object *parent, const std::string &file_path, glm::vec2 pos, float scale = 1.0f, Anchor anchor = Anchor::CENTER);
    virtual void render() override;

    Sprite *getIcon() const { return icon_; }
    void setIcon(Sprite *icon) { icon_ = icon; }
    float getPercentage() const { return percentage_; }
    void setPercentage(float percentage);
};

#endif // HUD_SKILL_H
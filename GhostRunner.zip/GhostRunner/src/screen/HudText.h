/* HUDText Class -> ObjectScreen Class -> Object Class
   テキストHUDシステム
   柔軟性：様々なフォント・サイズ・位置・スタイルに対応したテキスト表示が可能
   リアルタイム更新：テキスト内容がゲームの状態に合わせて動的に変化します
   使いやすさ：シンプルなインターフェースでテキスト表示の追加・更新が簡単にできる
   パフォーマンス最適化：テキスト描画は効率的に行われ、ゲームの動作に影響を与えないようにする
*/
#ifndef HUD_TEXT_H
#define HUD_TEXT_H

#include "../core/ObjectScreen.h"
#include "../affiliate/TextLabel.h"
#include "../affiliate/Sprite.h"

class HUDText : public ObjectScreen
{
protected:
    TextLabel *text_label_ = nullptr;
    Sprite *sprite_bg_ = nullptr;
    glm::vec2 size_ = glm::vec2(0, 0); // 背景画像の大きさ
public:
    static HUDText *addHUDTextChild(Object *parent, const std::string &text, glm::vec2 render_pos, glm::vec2 size, const std::string &font_path = "assets/font/VonwaonBitmap-16px.ttf", int font_size = 32, const std::string &bg_path = "assets/UI/Textfield_01.png", Anchor anchor = Anchor::CENTER);

    void setBgSizeByText(float margin = 50.0f); // 背景画像の大きさをセットする
    void setTextLabel(TextLabel *text_label) { text_label_ = text_label; }
    void setSpriteBg(Sprite *sprite) { sprite_bg_ = sprite; }
    TextLabel *getTextLabel() const { return text_label_; }
    Sprite *getSpriteBg() const { return sprite_bg_; }

    void setText(const std::string &text) { text_label_->setText(text); }
    std::string getText() const { return text_label_->getText(); }
    void setSize(const glm::vec2 &size);

    void setBackgroud(const std::string &file_path);
};

#endif // HUD_TEXT_H
/* UIMouse Class -> ObjectScreen Class -> Object Class
   カスタムマウスポインター
   マウスカーソルの位置は画面座標系に基づいて決定され、ゲーム内のワールド座標系の影響を受けません
   美術的一貫性：カスタムカーソルはゲーム全体の美術スタイルに統一感を持たせることが可能
   視覚的フィードバック：カーソルの変化で直感的な操作反応を表示可能
   動的効果：システムカーソルでは実現できないアニメーション、拡大縮小、回転などの効果を実装
   機能説明：ゲームの状態やプレイヤーの操作に応じてカーソル表示を切り替え、現在可能なアクションを視覚的に示す
   ゲームの没入感：ゲーム全体の臨場感とクオリティを高める
 */
#ifndef UI_MOUSE_H
#define UI_MOUSE_H

#include "../core/ObjectScreen.h"
#include "../affiliate/Sprite.h"

class UIMouse : public ObjectScreen
{
protected:
    Sprite *sprite1_ = nullptr;
    Sprite *sprite2_ = nullptr;
    float timer_ = 0;

public:
    static UIMouse *addUIMouseChild(Object *parent, const std::string &file_path1, const std::string &file_path2, float scale = 1.0f, Anchor anchor = Anchor::CENTER);
    virtual void update(float dt) override;

    Sprite *getSprite1() const { return sprite1_; }
    Sprite *getSprite2() const { return sprite2_; }
    void setSprite1(Sprite *sprite) { sprite1_ = sprite; }
    void setSprite2(Sprite *sprite) { sprite2_ = sprite; }
};

#endif // UI_MOUSE_H
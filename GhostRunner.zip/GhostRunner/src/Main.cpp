/* Main ゲームプログラムの起動エントリポイント
 */
#include "core/Game.h"

int main(int, char **)
{
    auto &game = Game::GetInstance();    // Gameのシングルトンインスタンスを取得します
    game.init("GhostRunner", 1280, 720); // ゲームを初期化して、タイトルとウィンドウサイズを設定します
    game.run();                          // ゲームのメインループを開始する
    return 0;
}
/* Spell Class -> ObjectWorld Class -> ObjectScreen Class -> Object Class
   魔法システム
   戦闘の多様性：基本の近接攻撃や遠距離攻撃にとどまらない、多彩な攻撃手段を提供
   戦略性の深み：各呪文ごとに効果・消費 MP・クールダウンが異なり、プレイヤーは戦略的に使用タイミングを見極める必要がある
   視覚効果：魔法の発動時には華やかなエフェクトが伴い、ゲームのビジュアル体験を向上させます
   ゲームバランス調整：魔法のダメージ量、効果範囲、クールダウン時間を調整することで、ゲーム全体のバランスを最適化できます
   キャラクター成長：ゲーム進行に応じて、プレイヤーは新たな魔法を習得したり既存の魔法を強化でき、これがキャラクター成長システムを構成します
*/
#ifndef SPELL_H
#define SPELL_H

#include "../core/ObjectWorld.h"
#include "../affiliate/SpriteAnim.h"

class Spell : public ObjectWorld
{
protected:
    SpriteAnim *sprite_ = nullptr;
    float damage_ = 60.0f;

public:
    static Spell *addSpellChild(Object *parent, const std::string &file_path, glm::vec2 pos, float damage, float scale = 1.0f, Anchor anchor = Anchor::CENTER);
    void update(float dt) override;

    float getDamage() const { return damage_; }
    void setDamage(float damage) { damage_ = damage; }
    SpriteAnim *getSpriteAnim() const { return sprite_; }
    void setSpriteAnim(SpriteAnim *sprite) { sprite_ = sprite; }

private:
    void attack();
};

#endif // SPELL_H
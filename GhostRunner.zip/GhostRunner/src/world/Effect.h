/* Effect Class -> ObjectWorld Class -> ObjectScreen Class -> Object Class
   エフェクトシステム
   一時的な性質：エフェクトは通常短時間で終了するため、再生後に自動的に解除される必要があります
   独立性：エフェクトは独立したオブジェクトとして、ゲームワールドの任意の位置に配置可能であること
   連続性：特定の状況では、前のエフェクト終了後に次のイベントやエフェクトを発生させる必要がある
   多様性：爆発、閃光、煙など様々な視覚効果に対応
   使いやすさ：ゲーム内で様々なエフェクトを簡単に追加できるインターフェースを提供
   ObjectWorldを継承しており、ゲームワールド内の任意の位置に配置可能です
   SpriteAnimコンポーネントでアニメーションを表示し、終了後は自動的に消えるようにする
   next_object_ポインタを追加しました。これによりエフェクト終了時に別のオブジェクトをシーンに追加できるようになり、エフェクトチェーンや連続イベントの実装基盤が整いました
 */
#ifndef EFFECT_H
#define EFFECT_H

#include "../core/ObjectWorld.h"
#include "../affiliate/SpriteAnim.h"
#include <string>

class Effect : public ObjectWorld
{
    SpriteAnim *sprite_ = nullptr;
    ObjectWorld *next_object_ = nullptr;

public:
    static Effect *addEffectChild(Object *parent, const std::string &file_path, glm::vec2 pos, float scale = 1.0f, ObjectWorld *next_object = nullptr);
    virtual void update(float dt) override;
    virtual void clean() override;

    void setSpriteAnim(SpriteAnim *sprite) { sprite_ = sprite; }
    SpriteAnim *getSpriteAnim() { return sprite_; }
    void setNextObject(ObjectWorld *next_object) { next_object_ = next_object; }
    ObjectWorld *getNextObject() { return next_object_; }

private:
    void checkFinish();
};

#endif // EFECT_H
/* SceneMain Class -> Scene Class -> Object Class
   ゲームメインステージ
 */
#ifndef SCENE_MAIN_H
#define SCENE_MAIN_H

#include "core/Scene.h"

class Spawner;
class Player;
class UIMouse;
class HUDStats;
class HUDText;
class HUDButton;
class Timer;
class SceneMain : public Scene
{
protected:
    Player *player_ = nullptr;            // プレイヤー
    Spawner *spawner_ = nullptr;          // 敵生成
    UIMouse *ui_mouse_ = nullptr;         // マウスUI
    HUDStats *hud_stats_ = nullptr;       // プレイヤー状態HUD
    HUDText *hud_text_score_ = nullptr;   // スコアHUD
    HUDButton *button_pause_ = nullptr;   // 一時停止ボタン
    HUDButton *button_restart_ = nullptr; // リスタートボタン
    HUDButton *button_back_ = nullptr;    // 戻るボタン
    Timer *end_timer_ = nullptr;          // ゲーム終了タイマー

public:
    SceneMain() = default;
    virtual ~SceneMain() = default;

    virtual void init() override;
    virtual bool handleEvents(SDL_Event &event) override;
    virtual void update(float dt) override;
    virtual void render() override;
    virtual void clean() override;
    virtual void saveData(const std::string &file_path) override;

private:
    void renderBackground();

    void updateScore();

    void checkButtonPause();
    void checkButtonRestart();
    void checkButtonBack();

    void checkEndTimer();

    void checkSlowDown(float &dt);
};

#endif // SCENE_MAIN_H
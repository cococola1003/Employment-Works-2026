/* Weapon Class -> Object Class
   武器システム
   攻撃の多様性：異なる武器が異なる攻撃方法、範囲、効果を提供
   キャラクター成長：新たな武器を入手したり既存の武器を強化することで、キャラクターの能力を向上させる
   リソース管理：武器にはクールダウン時間やリソース消費があるため、プレイヤーはこれらを合理的に管理する必要がある
   戦略的選択：異なるシナリオや敵タイプには、異なる武器が適している可能性がある
   ゲームバランス：武器のダメージ、クールダウン時間、消費を調整することで、ゲームのバランスを実現
*/
#ifndef WEAPON_H
#define WEAPON_H

#include "../core/Object.h"

class Spell;
class Actor;
class Weapon : public Object
{
protected:
    Actor *parent_ = nullptr;
    float cool_down_ = 1.0f;
    float mana_cost_ = 0.0f;
    float cool_down_timer_ = 0.0f;

public:
    virtual void update(float dt) override;

    void attack(glm::vec2 position, Spell *spell);
    bool canAttack();

    float getCoolDown() const { return cool_down_; }
    void setCoolDown(float cool_down) { cool_down_ = cool_down; }
    float getManaCost() const { return mana_cost_; }
    void setManaCost(float mana_cost) { mana_cost_ = mana_cost; }
    void setParent(Actor *parent) { parent_ = parent; }
    Actor *getParent() const { return parent_; }
};

#endif // WEAPON_H
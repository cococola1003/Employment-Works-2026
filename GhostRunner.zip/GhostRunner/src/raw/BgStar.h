/* BgStar Class -> Object Class
   視差効果のある星空スクロール
   多層の星空背景をデザインする（遠景、中景、近景の3 層）
   各層の星ごとに異なる移動速度を設定する（カメラ位置の拡大縮小で実装）
   星の描画手法を実装（スプライトではなく点描画を使用することで処理効率を向上）
   視覚効果を追加する（星の色が変化するなど）
*/
#ifndef BG_STAR_H
#define BG_STAR_H

#include "../core/Object.h"

class BgStar : public Object
{
protected:
    std::vector<glm::vec2> star_far_;
    std::vector<glm::vec2> star_mid_;
    std::vector<glm::vec2> star_near_;
    float scale_far_ = 0.2;
    float scale_mid_ = 0.5;
    float scale_near_ = 0.7;
    SDL_FColor color_far_ = {0, 0, 0, 1};
    SDL_FColor color_mid_ = {0, 0, 0, 1};
    SDL_FColor color_near_ = {0, 0, 0, 1};
    float timer_ = 0;
    int num_ = 2000; // 各階層の星の数

public:
    static BgStar *addBgStarChild(Object *parent, int num, float scale_far, float scale_mid, float scale_near);
    virtual void update(float dt) override;
    virtual void render() override;

    float getScaleFar() const { return scale_far_; }
    void setScaleFar(float scale_far) { scale_far_ = scale_far; }
    float getScaleMid() const { return scale_mid_; }
    void setScaleMid(float scale_mid) { scale_mid_ = scale_mid; }
    float getScaleNear() const { return scale_near_; }
    void setScaleNear(float scale_near) { scale_near_ = scale_near; }
};

#endif // BG_STAR_H
/* Timer Class -> Object Class
   汎用タイマー部品
   柔軟な設定が可能：時間間隔を自由に設定できます
   状態制御：起動・停止・リセットが可能
   進捗確認：現在の計測状況を確認できます
   タイムアウト検知：時間切れを検出可能
   自動管理：オブジェクト階層に統合され、管理が容易
*/
#ifndef TIMER_H
#define TIMER_H

#include "../core/Object.h"

class Timer : public Object // 作成時、デフォルトで!active 状態になります
{
protected:
    float timer_ = 0;
    float interval_ = 3.0f;
    bool time_out_ = false;

public:
    static Timer *addTimerChild(Object *parent, float interval = 3.0f);

    virtual void update(float dt) override;

    void start() { is_active_ = true; }
    void stop() { is_active_ = false; }
    bool timeOut();
    float getProgress() { return timer_ / interval_; }

    float getTimer() const { return timer_; }
    void setTimer(float timer) { timer_ = timer; }
    float getInterval() const { return interval_; }
    void setInterval(float interval) { interval_ = interval; }
};

#endif // TIMER_H
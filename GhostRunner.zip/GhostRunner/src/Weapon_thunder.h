/* Weapon_thunder Class -> Weapon Class -> Object Class
   特定種別の武器
   雷属性の魔法を発動するために特化した
*/
#ifndef WEAPON_THUNDER_H
#define WEAPON_THUNDER_H

#include "raw/Weapon.h"
#include "screen/HudSkill.h"

class WeaponThunder : public Weapon
{
protected:
    HUDSkill *hud_skill_ = nullptr;

public:
    virtual void init() override;
    virtual void update(float dt) override;
    static WeaponThunder *addWeaponThunderChild(Actor *parent, float cool_down, float mana_cost);

    virtual bool handleEvents(SDL_Event &event) override;
};

#endif // WEAPON_THUNDER_H
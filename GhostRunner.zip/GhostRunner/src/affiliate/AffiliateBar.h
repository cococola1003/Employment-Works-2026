/* AffiliateBar Class -> ObjectAffiliate Class -> Object Class
   直感的なHPバーの表示
   1.動的表示：キャラクターの現在の体力値をパーセントでリアルタイム表示
   2.色の変化：HPの割合に応じて色が変わり、視覚的に状態がわかりやすくなります
   3.配置の自由度が高い：任意のゲームオブジェクトにアタッチ可能で、相対位置を設定できます
   4.自動更新：キャラクターの体力値の変化に合わせて表示が自動的に更新されます
*/
#ifndef AFFILIATE_BAR_H
#define AFFILIATE_BAR_H

#include "../core/ObjectAffiliate.h"

class AffiliateBar : public ObjectAffiliate
{
protected:
    float percentage_ = 1.0f;
    SDL_FColor color_high_ = {0, 1, 0, 1};    // 緑色
    SDL_FColor color_mid_ = {1, 0.65f, 0, 1}; // オレンジ色
    SDL_FColor color_low_ = {1, 0, 0, 1};     // 赤色

public:
    static AffiliateBar *addAffiliateBarChild(ObjectScreen *parrent, glm::vec2 size, Anchor anchor = Anchor::CENTER);
    virtual void render() override;

    float getPercentage() const { return percentage_; }
    void setPercentage(float percentage) { percentage_ = percentage; }

    SDL_FColor getColorHigh() const { return color_high_; }
    void setColorHigh(SDL_FColor color) { color_high_ = color; }
    SDL_FColor getColorMid() const { return color_mid_; }
    void setColorMid(SDL_FColor color) { color_mid_ = color; }
    SDL_FColor getColorLow() const { return color_low_; }
    void setColorLow(SDL_FColor color) { color_low_ = color; }
};

#endif // AFFILIATE_BAR_H
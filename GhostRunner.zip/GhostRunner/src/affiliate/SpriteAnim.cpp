#include "SpriteAnim.h"

SpriteAnim *SpriteAnim::addSpriteAnimChild(ObjectScreen *parent, const std::string &file_path, float scale, Anchor anchor)
{
    auto sprite_anim = new SpriteAnim();
    sprite_anim->init();
    sprite_anim->setTexture(Texture(file_path));
    sprite_anim->setScale(scale);
    sprite_anim->setParent(parent);
    sprite_anim->setOffsetByAnchor(anchor);
    parent->addChild(sprite_anim);
    return sprite_anim;
}

void SpriteAnim::update(float dt)
{
    if (is_finish_)
        return;                      // アニメーションが完了済みの場合は更新しません
    frame_timer_ += dt;              // 経過時間をフレームタイマーに加算する
    if (frame_timer_ >= 1.0f / fps_) // 次のフレームのタイミングに達したか確認する（フレームレートから算出）
    {
        current_frame_++;                    // 現在のフレームインデックスを増やす
        if (current_frame_ >= total_frames_) // 現在のフレームが総フレーム数を超えた場合、最初のフレームに戻ります（ループ再生）
        {
            current_frame_ = 0;
            if (!is_loop_)
                is_finish_ = true; // ループ再生でない場合、アニメーションを終了状態に設定する
        }
        frame_timer_ = 0.0f; // フレームタイマーをリセットする
    }
    texture_.src_rect.x = texture_.src_rect.w * current_frame_; // 現在のフレームを表示するためにテクスチャの表示領域を更新
}

void SpriteAnim::setTexture(const Texture &texture)
{
    // スプライトシートが横並びに配置されている場合、各フレームの幅と高さは等しくなります（つまりフレームは正方形です）
    texture_ = texture;
    total_frames_ = static_cast<int>(std::round(texture.src_rect.w / texture.src_rect.h));
    texture_.src_rect.w = texture.src_rect.h;
    size_ = glm::vec2(texture_.src_rect.w, texture_.src_rect.h);
}
/* TextLabel Class -> ObjectAffiliate Class -> Object Class
   基本テキストタグ、文字の表示と管理を担当します
*/
#ifndef TEXT_LABEL_H
#define TEXT_LABEL_H

#include "../core/ObjectAffiliate.h"
#include <string>

class TextLabel : public ObjectAffiliate
{
protected:
    TTF_Text *ttf_text_ = nullptr;
    std::string font_path_;
    int font_size_ = 16;

public:
    static TextLabel *addTextLabelChild(ObjectScreen *parent, const std::string &text, const std::string &font_path, int font_size, Anchor anchor = Anchor::CENTER);
    virtual void render() override;
    virtual void clean() override;

    void setFont(const std::string &font_path, int font_size); // init() の直後に呼び出す
    void setFontPath(const std::string &font_path);
    void setFontSize(int font_size);
    void setText(std::string ttf_text);
    std::string getText() const { return ttf_text_->text; }

private:
    void updateSize(); // 文字の内容に応じてサイズを調整する
};

#endif // TEXT_LABEL_H
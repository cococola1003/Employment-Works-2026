/* Collider Class -> ObjectAffiliate Class -> Object Class
   当たり判定ボックス
   以前に構築されたオブジェクト関連システムに従う
   コリジョンボックスはObjectScreenタイプのオブジェクトに追加可能です
 */
#ifndef COLLIDER_H
#define COLLIDER_H

#include "../core/ObjectAffiliate.h"

class Spell;
class Collider : public ObjectAffiliate
{
protected:
    friend Spell;   // フレンド機能により、Spellクラスはプライベートメンバーにアクセス可能です
    enum class Type // 円形と矩形の2 種類の当たり判定形状に対応
    {
        CIRCLE,
        RECTANGLE
    };
    Type type_ = Type::CIRCLE;

public:
    virtual void render() override; // 当たり判定ボックスの表示に使用（デバッグ時のみ）

    static Collider *addColliderChild(ObjectScreen *parent, glm::vec2 size, Type type = Type::CIRCLE, Anchor anchor = Anchor::CENTER); // 静的ファクトリメソッドはコライダーの作成とアタッチに使用されます
    bool isColliding(Collider *other);                                                                                                 // 他の衝突判定オブジェクトとの交差を検出

    Type type() const { return type_; }       // 当たり判定ボックスの種類を取得
    void setType(Type type) { type_ = type; } // 当たり判定のタイプを設定
};

#endif // COLLIDER_H
/* SpriteAnim Class -> Sprite Class
   スプライトアニメーションクラス
*/
#ifndef SPRITE_ANIM_H
#define SPRITE_ANIM_H

#include "Sprite.h"

class SpriteAnim : public Sprite
{
    int current_frame_ = 0;    // 現在表示中のアニメーションフレーム
    int total_frames_ = 0;     // アニメーションの総フレーム数を表示する
    int fps_ = 10;             // 1 秒間のフレームレートを表示
    float frame_timer_ = 0.0f; // フレーム切り替えのタイミングを制御する
    bool is_loop_ = true;      // アニメーションをループ再生するかどうか

public:
    static SpriteAnim *addSpriteAnimChild(ObjectScreen *parent, const std::string &file_path, float scale = 1.0f, Anchor anchor = Anchor::CENTER); // ファクトリメソッドでアニメーションスプライトを作成・設定する
    virtual void update(float dt) override;

    virtual void setTexture(const Texture &texture) override;

    int getCurrentFrame() const { return current_frame_; }
    void setCurrentFrame(int current_frame) { current_frame_ = current_frame; }
    int getTotalFrames() const { return total_frames_; }
    void setTotalFrames(int total_frames) { total_frames_ = total_frames; }
    int getFps() const { return fps_; }
    void setFps(int fps) { fps_ = fps; }
    float getFrameTimer() const { return frame_timer_; }
    void setFrameTimer(float frame_timer) { frame_timer_ = frame_timer; }
    bool getLoop() const { return is_loop_; }
    void setLoop(bool is_loop) { is_loop_ = is_loop; }
};

#endif // SPRITE_ANIM_H
/* Sprite Class -> ObjectAffiliate Class -> Object Class
   ゲームでよく使われる2D 画像の表現形式で、キャラクターやオブジェクト、エフェクトなどを表示する際に一般的に用いられます
   1.ビジュアル表現：画像の表示（アニメーション・回転・ズームなどの効果を含む場合あり）
   2.組み合わせ性：ゲームオブジェクトは複数のスプライト部品を持つ場合があります（例：キャラクターの身体、武器、装備など）
   3.簡単な使い方：ゲームオブジェクトにスプライトを簡単に追加できます
   4.リソース管理：テクスチャリソースの効率的な管理と活用
   5.描画順序：異なるスプライト間の描画順序を制御します
 */
#ifndef SPRITE_H
#define SPRITE_H

#include "../core/ObjectAffiliate.h"
#include <string>

struct Texture
{
    SDL_Texture *texture = nullptr;
    SDL_FRect src_rect = {0, 0, 0, 0};
    float angle = 0;
    bool is_flip = false;
    Texture() = default;
    Texture(const std::string &file_path);
};

class Sprite : public ObjectAffiliate
{
protected:
    Texture texture_;
    bool is_finish_ = false;
    glm::vec2 percentage_ = glm::vec2(1.0f); // 画像の元の領域の割合を決定する

public:
    static Sprite *addSpriteChild(ObjectScreen *parrent, const std::string &file_path, float scale = 1.0f, Anchor anchor = Anchor::CENTER); // スプライトの子オブジェクトを追加

    virtual void render() override;

    void setScale(float scale) { size_ *= scale; } // 拡大縮小率を設定

    Texture getTexture() const { return texture_; }
    virtual void setTexture(const Texture &texture);
    void setFlip(bool is_flip) { texture_.is_flip = is_flip; }
    void setAngle(float angle) { texture_.angle = angle; }
    bool getFlip() const { return texture_.is_flip; }
    float getAngle() const { return texture_.angle; }
    bool getFinish() const { return is_finish_; }
    void setFinish(bool is_finish) { is_finish_ = is_finish; }
    glm::vec2 getPercentage() const { return percentage_; }
    void setPercentage(const glm::vec2 &percentage) { percentage_ = percentage; }
};

#endif // SPRITE_H
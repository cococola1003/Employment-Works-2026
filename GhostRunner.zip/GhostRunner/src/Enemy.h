/* Enemy Class -> Actor Class -> ObjectWorld Class -> ObjectScreen Class -> Object Class
   具体的な敵キャラクター
*/
#ifndef ENEMY_H
#define ENEMY_H

#include "Player.h"

class Enemy : public Actor
{
    enum class State
    {
        NORMAL,
        HURT,
        DIE
    };
    State current_state_ = State::NORMAL;

    Player *target_ = nullptr;

    SpriteAnim *anim_normal_ = nullptr; // 通常状態のアニメーション
    SpriteAnim *anim_hurt_ = nullptr;   // ダメージを受けたときのアニメーション
    SpriteAnim *anim_die_ = nullptr;    // 死亡時のアニメーション

    SpriteAnim *current_anim_ = nullptr; // 現在のアニメーション

    float timer_ = 0.0f; // タイマー

    int score_ = 10; // スコア

public:
    static Enemy *addEnemyChild(Object *parent, glm::vec2 pos, Player *target);
    virtual void init();
    virtual void update(float dt) override;

    void aim_target(Player *target);

    void checkState();
    void changeState(State new_state);
    void attack();
    void remove();

    Player *getTarget() { return target_; }
    void setTarget(Player *target) { target_ = target; }
};

#endif // ENEMY_H
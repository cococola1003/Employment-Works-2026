/* Player Class -> Actor Class -> ObjectWorld Class -> ObjectScreen Class -> Object Class
   具体的なプレイヤーキャラクター
*/
#ifndef PLAYER_H
#define PLAYER_H

#include "core/Actor.h"
#include "affiliate/SpriteAnim.h"
#include "world/Effect.h"
#include "Weapon_thunder.h"

class Timer;
class Player : public Actor
{
    SpriteAnim *sprite_idle_ = nullptr;       // プレイヤーが静止状態時のアニメーション
    SpriteAnim *sprite_move_ = nullptr;       // プレイヤーの移動アニメーション
    Effect *effect_ = nullptr;                // プレイヤーの死亡エフェクト
    WeaponThunder *weapon_thunder_ = nullptr; // プレイヤーの武器
    bool is_moving_ = false;                  // プレイヤーが移動しているかどうか
    Timer *flash_timer_ = nullptr;            // 点滅タイマー

public:
    virtual void init() override;
    virtual bool handleEvents(SDL_Event &event) override;
    virtual void update(float dt) override;
    virtual void render() override;
    virtual void clean() override;

    void keyboardControl();           // キーボード操作：WASDキーでプレイヤーを移動
    void syncCamera();                // カメラ同期：プレイヤーを追従して画面中央に表示する
    void checkState();                // 状態確認：プレイヤーの移動が停止したら待機状態に移行、移動中なら移動状態に移行する
    void changeState(bool is_moving); // 状態切替：is_movingパラメータにより停止状態と移動状態を切り替えます
    void checkIsDead();               // 死亡判定：プレイヤーのHPが0 以下になった場合、死亡処理を実行する

    virtual void takeDamage(float damage) override; // プレイヤーが被ダメージ
};

#endif // PLAYER_H